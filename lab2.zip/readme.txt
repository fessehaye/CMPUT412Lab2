LAB2 CMPUT 412:
Simon Fessehaye
Jonathon Machinski

All java files are found under the src folder. Report and README are with the same default directory.

To test (4 or 5):
1.set motors to A and B port
2.connect to EV3
3.open ForwardKinematics.java
4.choose which function you want to test on the main function by commenting the rest
5.run ForwardKinematics.java on the EV3

To test (6 or 7):
1.set motors to A and B port
2.connect to EV3
3.open InverseKinematics.java
4.choose which function you want to test on the main function by commenting the rest
5.run InverseKinematics.java on the EV3

or to try the numerical method of Q6

1.set motors to A and B port
2.connect to EV3
3.open Numeric2DOF.java
4.change the inputs of newtonsmethod() function for testing
5.run Numeric2DOF.java on the EV3

To test (8 or 9):
1.set motors to A,B and C port 
2.connect to EV3
3.open pathplanning.java
4.choose which function you want to test on the main function by commenting the rest
5.run pathplanning.java on the EV3

To test (12):(need two light sensors)
1.set motors to A,B and C port 
2.connect to EV3
3.open InvKinematic3D.java
4.change the inputs of goHere() function for testing
5.run InvKinematic3D.java on the EV3
